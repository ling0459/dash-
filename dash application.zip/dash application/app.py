from operator import itemgetter

import dash
import dash_bootstrap_components as dbc
import dash_core_components as dcc
import dash_html_components as html
import dash_table
from dash.dependencies import Input, Output, State

# drop down list for use in airport codes
from controls import city_df, airlines_df, routes_df, airport_df

# setup app with stylesheets
app = dash.Dash(external_stylesheets=[dbc.themes.SOLAR])





# Create map template
mapbox_access_token = \
    'pk.eyJ1IjoibW9kZXN0dHJhZGVyIiwiYSI6ImNrbng5ZTlxODA4aDEyd3Bmd2ltaGplYnYifQ.j9Uzs_RK339cDIdRnMR8rg'


layout = dict(
    autosize=True,
    automargin=True,
    margin=dict(l=5, r=5, b=5, t=5),
    hovermode='closest',
    # title='Flights, Routes, and Analysis',
    mapbox=dict(
        accesstoken=mapbox_access_token,
        center=dict(lon=-98.5795, lat=39.8283),
        zoom=2,
    ),
)

controls = dbc.Card(
    [
        dbc.FormGroup(
            [
                dbc.Label('Airline', className='text-dark'),
                dcc.Dropdown(
                    options=[{'label': col, 'value': col} for col in airlines_df['Name']],
                    value='',
                    id='airline',
                ),
            ]
        ),
        dbc.FormGroup(
            [
                dbc.Label('Start City', className='text-dark'),
                dcc.Dropdown(
                    options=[{'label': col, 'value': col} for col in city_df['City']],
                    value='',
                    id='start-city',
                    disabled=True
                ),
            ]
        ),
        dbc.FormGroup(
            [
                dbc.Label('Start City Airport', className='text-dark'),
                dcc.Dropdown(
                    options=[{'label': col, 'value': col} for col in city_df['City']],
                    value='',
                    id='start-city-airport',
                    disabled=True
                ),
            ]
        ),
        dbc.FormGroup(
            [
                dbc.Label('Destination City', className='text-dark'),
                dcc.Dropdown(
                    options=[{'label': col, 'value': col} for col in city_df['City']],
                    value='',
                    id='destination-city',
                    disabled=True
                ),
            ]
        ),
        dbc.FormGroup(
            [
                dbc.Label('Destination City Airport', className='text-dark'),
                dcc.Dropdown(
                    options=[{'label': col, 'value': col} for col in city_df['City']],
                    value='',
                    id='destination-city-airport',
                    disabled=True
                ),
            ]
        ),
        dbc.Button('Find Route',
                   id='find-route-button',
                   outline=True, className='mr-1'),
    ],
    body=True,
)

app.layout = dbc.Container(
    [
        dbc.Row(
            [
                dbc.Col(html.H2(), md=3),
                dbc.Col(
                    html.H2('Kartemap - Flight Route Analysis',
                            className='text-white'), md=9
                )
            ], align='center', className='bg-info'),
        dbc.Row(
            [
                dbc.Col(controls, md=3),
                dbc.Col(dcc.Graph(id='map'), md=9),
            ],
            align='center', className='bg-info',
        ),
        dbc.Row(
            [
                dbc.Col(dash_table.DataTable(id='shortest-path-table'), md=12),
            ],
            align='center', className='bg-info',
        ),
        dbc.Row(
            [
                dbc.Col(html.H2(), md=3),
                dbc.Col(
                    html.H6('Copyright (C) 2021, Brandeis University Course: Python and '
                            'Applications to Business Analytics II, All Rights Reserved.',
                            className='text-white'), md=9
                )
            ], align='center', className='bg-info'),

    ],
    id='main-container',
    style={'display': 'flex', 'flex-direction': 'column'},
    fluid=True
)


# airline selected, populate and enable start and destination city controls
#
@app.callback([Output('start-city', 'options'),
               Output('start-city', 'disabled'),
               Output('destination-city', 'options'),
               Output('destination-city', 'disabled')],
              [Input('airline', 'value')])
def populate_city_controls_after_airline_selected(airline):
    if airline == '':
        return [], True, [], True

    # retrieve the airline_id for the selected airline
    selected_airline_as_list = airlines_df.query('Name=="{}"'.format(airline))['Airline_id'].tolist()
    airline_id = selected_airline_as_list[0]

    # get all routes for the selected airline
    airline_routes_df = routes_df.copy()

    airline_routes_df = airline_routes_df.query('Airline_id=={}'.format(airline_id))

    # get city name for start and destination airports
    start_airport_ids = airline_routes_df['Source_airport_id'].to_list()
    start_city_df = airport_df[airport_df['Airport_id'].isin(start_airport_ids)]

    # populate source and destination city list for the dropdown controls
    destination_airport_ids = list(airline_routes_df['Destination_airport_id'])

    destination_city_df = airport_df[airport_df['Airport_id'].isin(destination_airport_ids)]

    start_city_options = [{'label': col, 'value': col} for col in start_city_df['City']]

    start_city_options = sorted(start_city_options, key=itemgetter('value'))
    destination_city_options = [{'label': col, 'value': col} for col in destination_city_df[
        'City']]
    destination_city_options = sorted(destination_city_options, key=itemgetter('value'))

    return start_city_options, False, destination_city_options, False


# start or destination city selected, populate start or destination airport
#
@app.callback([Output('start-city-airport', 'options'),
               Output('start-city-airport', 'disabled'),
               Output('destination-city-airport', 'options'),
               Output('destination-city-airport', 'disabled')],
              [Input('airline', 'value'),
               Input('start-city', 'value'),
               Input('destination-city', 'value')])
def populate_airport_controls_after_city_selected(airline, start_city, destination_city):
    if start_city == '':
        start_city_airport_options = []
        start_city_airport_disable = True
    else:
        # retrieve the airline_id for a given airline name
        ctl_routes_df = routes_df.copy()
        selected_airline_as_list = airlines_df.query('Name=="{}"'.format(airline))['Airline_id'].tolist()
        airline_id = selected_airline_as_list[0]

        # get all routes for the selected airline
        ctl_routes_df = ctl_routes_df.query('Airline_id=={}'.format(airline_id))

        # get source airport
        source_airport_ids = ctl_routes_df['Source_airport_id'].to_list()
        ctl_src_airport_df = airport_df[airport_df['Airport_id'].isin(source_airport_ids)]
        ctl_src_airport_df = ctl_src_airport_df.query('City=="{}"'.format(start_city))
        start_city_airport_options = [{'label': col, 'value': col} for col in
                                      ctl_src_airport_df['Name']]
        start_city_airport_options.sort()
        start_city_airport_disable = False

    if destination_city == '':
        destination_city_airport_options = []
        destination_city_airport_disable = True
    else:
        # retrieve the airline_id for a given airline name
        ctl_routes_df = routes_df.copy()
        selected_airline_as_list = airlines_df.query('Name=="{}"'.format(airline))['Airline_id'].tolist()
        airline_id = selected_airline_as_list[0]

        # get all routes for the selected airline
        ctl_routes_df = ctl_routes_df.query('Airline_id=={}'.format(airline_id))

        # get destination airport
        destination_airport_ids = ctl_routes_df['Destination_airport_id'].to_list()
        ctl_dest_airport_df = airport_df[airport_df['Airport_id'].isin(destination_airport_ids)]
        ctl_dest_airport_df = ctl_dest_airport_df.query('City=="{}"'.format(destination_city))
        destination_city_airport_options = [{'label': col, 'value': col} for col in
                                            ctl_dest_airport_df['Name']]
        destination_city_airport_options.sort()
        destination_city_airport_disable = False

    return start_city_airport_options, start_city_airport_disable, \
           destination_city_airport_options, destination_city_airport_disable


@app.callback(Output('map', 'figure'),
              [Input('start-city', 'value'),
               Input('destination-city', 'value')],
              [State('map', 'relayoutData')])
def make_map(start_city, destination_city, map_layout):
    traces = []
    for name, df in airport_df.groupby('City'):
        trace = dict(
            type='scattermapbox',
            lon=df['Longitude'],
            lat=df['Latitude'],
            text=df['City'],
            showlegend=False,
            marker=dict(
                size=10 if name in [start_city, destination_city] else 5,
                opacity=0.95 if name in [start_city, destination_city] else 0.65,
                symbol='circle',
                color='red' if name in [start_city, destination_city] else 'blue',
            ),
            visible=True
        )
        traces.append(trace)

    # relayoutData is None by default, and {'autosize': True} without relayout action
    if map_layout is not None:
        if 'mapbox.center' in map_layout.keys():
            lon = float(map_layout['mapbox.center']['lon'])
            lat = float(map_layout['mapbox.center']['lat'])
            zoom = float(map_layout['mapbox.zoom'])
            layout['mapbox']['center']['lon'] = lon
            layout['mapbox']['center']['lat'] = lat
            layout['mapbox']['zoom'] = zoom

    figure = dict(data=traces, layout=layout)
    return figure








#def compute_distance_in_kilometers(start_city_airport, destination_city_airport):
#
#    phi_1 = lat1 * math.pi / 180.0
#    phi_2 = lat2 * math.pi / 180.0
#    change_phi = (lat2 - lat1) * math.pi / 180
#    change_lambda = (lon2 - lon1) * math.pi / 180
#
#    a = math.sin(change_phi / 2.0) * math.sin(change_phi / 2.0) + math.cos(phi_1) * \
#        math.cos(phi_2) * math.sin(change_lambda / 2.0) * math.sin(change_lambda / 2.0)
#    c = 2.0 * math.atan2(math.sqrt(a), math.sqrt(1.0 - a))
#    return 6371.0 * c


if __name__ == '__main__':
    app.run_server(debug=True)
